package com.api.constants;

public class DataConstarints {

}
