package com.api.constants;

public class EndPoints {

	public static final String GET_ALL_MANUFACTURER = "manufacturers";	
	public static final String GET_SINGLE_MANUFACTURER = "manufacturers/{id}";
	public static final String CREATE_MANUFACTURER = "manufacturers";
	public static final String UPDATE_MANUFACTURER = "manufacturers/{id}";
	public static final String DELETE_MANUFACTURER = "manufacturers/{id}";
}
