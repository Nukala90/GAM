package com.api.constants;

public class Browser {

}
