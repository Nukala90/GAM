package com.api.helpers;

import static org.testng.Assert.assertEquals;

import java.lang.reflect.Type;
import java.util.List;

import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;

import com.api.constants.EndPoints;
import com.api.model.Manufacturer;
import com.api.utils.ConfigManager;
import com.fasterxml.jackson.core.type.TypeReference;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class ManufacturerServiceHelper {

	// functions basically fetch the data from End points.
	// GET/POST/PUT Single/Patch/Delete
	// we need to read the config variables
	// Rest Assured about the URL, Port
	// Make a Get REQUEST on this url and send the data to TestGETManufacturer

	private static final String BASE_URL = ConfigManager.getInstance().getString("base_url");
	private static final String PORT = ConfigManager.getInstance().getString("port");

	public ManufacturerServiceHelper() {
		RestAssured.baseURI = BASE_URL;
		RestAssured.port = Integer.parseInt(PORT);
	}

	public List<Manufacturer> getAllManufacturers() {

		Response response = RestAssured.given()
				.contentType(ContentType.JSON)
				.get(EndPoints.GET_ALL_MANUFACTURER)
				.andReturn();
		Type type = new TypeReference<List<Manufacturer>>() {
		}.getType();
		assertEquals(response.statusCode(), HttpStatus.SC_OK);
		List<Manufacturer> manuafcturerList = response.as(type);
		return manuafcturerList;
	}
	
	public List<Manufacturer> getMatchedManufacturersWithQueryParam() {

		Response response = RestAssured.given()
				.contentType(ContentType.JSON)
				.get(EndPoints.GET_ALL_MANUFACTURER)
				.andReturn();
		Type type = new TypeReference<List<Manufacturer>>() {
		}.getType();
		assertEquals(response.statusCode(), HttpStatus.SC_OK);
		List<Manufacturer> manuafcturerList = response.as(type);
		return manuafcturerList;
	}

	public Response createManufacturer() {
		// Need to make post a call with request body
		// We alaready ahve mapped pojo class of manufacturer
		Manufacturer manufacturer = new Manufacturer();
		// we set the name
		manufacturer.setName("VisionMeter_QA");
		// response object create
		Response response = RestAssured.given().contentType(ContentType.JSON).when().body(manufacturer)
				.post(EndPoints.CREATE_MANUFACTURER).andReturn();
		assertEquals(response.getStatusCode(), HttpStatus.SC_CREATED, "Created");
		return response;
	}

	public Response updateManufacturer() {
		// Need to make post a call with request body
		// We alaready ahve mapped pojo class of manufacturer
		Manufacturer manufacturer = new Manufacturer();
		// we set the name
		manufacturer.setName("VisionMeter_QATest");
		// response object create

		String requestManufacturId = "1";
		RequestSpecification request = RestAssured.given().pathParam("id", requestManufacturId);
		request.baseUri(BASE_URL);
		request.body(manufacturer);
		request.contentType(ContentType.JSON);

		// response object create
		Response response = request.put(EndPoints.UPDATE_MANUFACTURER).andReturn();
		// Print Response
		String resString = response.asString();
		System.out.println("Response Details of Update Manufacturer : " + resString);
		/*
		 * To perform validation on response like status code or value, we need to get
		 * ValidatableResponse type of response using then() method of Response
		 * interface. ValidatableResponse is also an interface.
		 */
		ValidatableResponse validatableResponse = response.then();
		// It will check if status code is 200
		validatableResponse.statusCode(204);
		// It will check if status line is as expected
		// validatableResponse.body("id", Matchers.notNullValue());
		// validatableResponse.body("name", Matchers.equalTo("Shivansh"));

		assertEquals(response.getStatusCode(), HttpStatus.SC_NO_CONTENT, "Updated");
		return response;
	}

	public Response deleteManufacturer() {
		// Need to make delete a call with request body

		// Collect manufacturer id
		String requestManufacturId = "1";
		RequestSpecification request = RestAssured.given().pathParam("id", requestManufacturId);
		request.baseUri(BASE_URL);
		request.contentType(ContentType.JSON);

		// response object create
		Response response = request.delete(EndPoints.DELETE_MANUFACTURER).andReturn();
		// Print Response
		String resString = response.asString();
		System.out.println("Response Details of Delete Manufacturer : " + resString);
		/*
		 * To perform validation on response like status code or value, we need to get
		 * ValidatableResponse type of response using then() method of Response
		 * interface. ValidatableResponse is also an interface.
		 */
		ValidatableResponse validatableResponse = response.then();
		// It will check if status code is 200
		validatableResponse.statusCode(204);
		// It will check if status line is as expected
		// validatableResponse.body("id", Matchers.notNullValue());
		// validatableResponse.body("name", Matchers.equalTo("Shivansh"));

		assertEquals(response.getStatusCode(), HttpStatus.SC_NO_CONTENT, "Updated");
		return response;
	}

	public Response getManufacturer() {
		// Need to make a get call with request pathparam

		// Collect manufacturer id
		String requestManufacturId = "1";
		RequestSpecification request = RestAssured.given().pathParam("id", requestManufacturId);
		request.baseUri(BASE_URL);
		request.contentType(ContentType.JSON);

		// response object create
		Response response = request.delete(EndPoints.GET_SINGLE_MANUFACTURER).andReturn();
		// Print Response
		String resString = response.asString();
		System.out.println("Response Details of Get Manufacturer : " + resString);
		/*
		 * To perform validation on response like status code or value, we need to get
		 * ValidatableResponse type of response using then() method of Response
		 * interface. ValidatableResponse is also an interface.
		 */
		ValidatableResponse validatableResponse = response.then();
		// It will check if status code is 200
		validatableResponse.statusCode(200);
		// It will check if status line is as expected
		validatableResponse.body("id", Matchers.notNullValue());
		validatableResponse.body("name", Matchers.equalTo("VisionMeter_QATest"));
		assertEquals(response.getStatusCode(), HttpStatus.SC_OK, "Fetched");
		return response;
	}

}
