package com.api.test;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertNotNull;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.api.helpers.ManufacturerServiceHelper;

public class TestPOSTManufacturer {

	// initialize RestAssured and functions
	//Create assert and verify it
	
	private ManufacturerServiceHelper manufacturerServiceHelper;	
	@BeforeClass
	public void init() {
		manufacturerServiceHelper = new ManufacturerServiceHelper();		
	}	
	@Test
	public void testPOSTCreateManufacturer() {
		String manufacturerId = manufacturerServiceHelper.createManufacturer().jsonPath().getString("id");
		System.out.println(manufacturerId);
		assertNotNull(manufacturerId,"Manufacturer id is not null");		
	}
}
