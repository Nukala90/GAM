package com.api.test;

public class TestIntegrationManufacturer {
	// Create a resource
	// Verify the resource by Get call
	// Update details of resource
	// Verify the resource Update Details
	// Delete resource
	// Verify the resource if deleted
	
	

}
