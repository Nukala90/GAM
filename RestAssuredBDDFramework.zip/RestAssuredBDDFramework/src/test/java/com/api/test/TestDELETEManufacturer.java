package com.api.test;

public class TestDELETEManufacturer {

}
