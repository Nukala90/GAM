package com.api.test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertNotNull;
import java.util.List;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.api.helpers.ManufacturerServiceHelper;
import com.api.model.Manufacturer;


public class TestGETManufacturers {
	private ManufacturerServiceHelper manufacturerServiceHelper;	
	@BeforeClass
	public void init() {
		manufacturerServiceHelper = new ManufacturerServiceHelper();		
	}
	
	@Test
	public void testGetAllManufacturer() {		
		List<Manufacturer> manuafcturerList = manufacturerServiceHelper.getAllManufacturers();		
		assertNotNull(manuafcturerList,"Manufacturer List is not empty");
		assertFalse(manuafcturerList.isEmpty(),"Manufacturer List is not empty-True");		
	}
	
}

