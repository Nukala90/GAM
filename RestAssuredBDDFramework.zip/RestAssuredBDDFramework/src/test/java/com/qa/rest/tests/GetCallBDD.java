package com.qa.rest.tests;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
	

public class GetCallBDD {
	
	@Test
	public void test_numberOfCircuits2017_Season() {
		
		given().
		when().
			get("https://gorest.co.in//public/v2/users/100.json").
		then().
		assertThat().
		statusCode(200).
		and().
		body("MRData.CircuitTable.Circuits.circuitId", hasSize(17)).
		and().
		header("content-length", equalTo("3921"));		
		
		
	}

	
}
